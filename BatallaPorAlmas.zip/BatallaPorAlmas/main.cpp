#include "source.h"

#include <chrono>
int main() {
    Mundo* world = new Mundo(1000000);
    menu(world);
}
